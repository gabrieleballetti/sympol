# sympol
A module for symbolic manipulation of polytopes
