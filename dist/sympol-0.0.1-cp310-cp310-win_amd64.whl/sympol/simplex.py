from sympol import Polytope
